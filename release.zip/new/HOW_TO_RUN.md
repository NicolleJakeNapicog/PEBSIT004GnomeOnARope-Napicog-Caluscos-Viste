## How to Run
Exact steps to open/build/run (e.g., “Open Unity Hub → Add project → Open scene X → Press Play” or make build & ./run.sh) 