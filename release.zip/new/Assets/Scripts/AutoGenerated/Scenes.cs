//This class is auto-generated do not modify (TagsLayersScenesBuilder.cs) - blog.almostlogical.com
public static class Scenes
{
	public const string MAIN_SCENE = "MainScene";
}