//This class is auto-generated do not modify (TagsLayersScenesBuilder.cs) - blog.almostlogical.com
public static class Tags
{
	public const string UNTAGGED = "Untagged";
	public const string RESPAWN = "Respawn";
	public const string FINISH = "Finish";
	public const string EDITOR_ONLY = "EditorOnly";
	public const string MAIN_CAMERA = "MainCamera";
	public const string PLAYER = "Player";
	public const string GAME_CONTROLLER = "GameController";
}