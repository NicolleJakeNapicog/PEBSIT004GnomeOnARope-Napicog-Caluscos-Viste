//This class is auto-generated do not modify (TagsLayersScenesBuilder.cs) - blog.almostlogical.com
public static class Layers
{
	public const string DEFAULT = "Default";
	public const string TRANSPARENT_FX = "TransparentFX";
	public const string IGNORE_RAYCAST = "Ignore Raycast";
	public const string WATER = "Water";
	public const string UI = "UI";

	public const int DEFAULT_INT = 0;
	public const int TRANSPARENT_FX_INT = 1;
	public const int IGNORE_RAYCAST_INT = 2;
	public const int WATER_INT = 4;
	public const int UI_INT = 5;
}